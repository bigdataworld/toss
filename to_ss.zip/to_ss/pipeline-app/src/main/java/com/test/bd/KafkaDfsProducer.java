package com.test.bd;

/**
 * Java Class for Handling HDFS File Read and Kafka Producer
 */
public class KafkaDfsProducer {

    public static void main(String args[]) throws  Exception{

        String appProperty =args[0];
        AppUtils.streamHdfsData(appProperty);
    }



}
