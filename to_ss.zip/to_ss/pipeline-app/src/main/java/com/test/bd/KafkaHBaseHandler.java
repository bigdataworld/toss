package com.test.bd;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.TableOutputFormat;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.mapreduce.Job;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import scala.Tuple2;

import static org.apache.spark.sql.functions.*;

import java.util.Properties;
import java.util.UUID;



public class KafkaHBaseHandler {

    public static void main(String args[]) throws  Exception{


        Properties appProp = AppUtils.getProperties(args[0]);
        String zooKeeperServer = appProp.get("zooKeeperServer").toString();
        String kafkaBroker = appProp.get("kafkaBroker").toString();
        String kafkaTopic = appProp.get("kafkaTopic").toString();
        String sparkMode = appProp.get("sparkMode").toString();
        String hbaseTable = appProp.get("hbaseTable").toString();


        SparkSession sparkSession = SparkSession
                .builder()
                .appName("Kafka HBase Integration")
                .master(sparkMode)
                .getOrCreate();

        Dataset<Row> kafkaStream = sparkSession.readStream()
                .format("kafka")
                .option("kafka.bootstrap.servers", kafkaBroker)
                .option("subscribe", kafkaTopic)
                .load();

        Dataset<Row> streamdata = kafkaStream.selectExpr("CAST(value AS STRING)").alias("csv").select("csv.*");
        streamdata=streamdata
                .withColumn("Path", split(col("value"), "\\|").getItem(0))
                .withColumn("Replication", split(col("value"), "\\|").getItem(1))
                .withColumn("ModificationTime", split(col("value"), "\\|").getItem(2))
                .withColumn("AccessTime", split(col("value"), "\\|").getItem(3))
                .withColumn("PreferredBlockSize", split(col("value"), "\\|").getItem(4))
                .withColumn("BlocksCount", split(col("value"), "\\|").getItem(5))
                .withColumn("FileSize", split(col("value"), "\\|").getItem(6))
                .withColumn("NSQUOTA", split(col("value"), "\\|").getItem(7))
                .withColumn("DSQUOTA", split(col("value"), "\\|").getItem(8))
                .withColumn("Permission", split(col("value"), "\\|").getItem(9))
                .withColumn("UserName", split(col("value"), "\\|").getItem(10))
                .withColumn("GroupName", split(col("value"), "\\|").getItem(11));


        streamdata= streamdata.drop(col("value"));
        streamdata.writeStream().format("console").start().awaitTermination();

        JavaRDD<Row> rawRdd = streamdata.toJavaRDD();
        Configuration config = null;
        config = HBaseConfiguration.create();
        config.set("hbase.zookeeper.quorum", zooKeeperServer);
        config.set("hbase.zookeeper.property.clientPort", "2181");
        config.set("hbase.cluster.distributed", "true");
        //config.set("zookeeper.znode.parent","/hbase-unsecure");
        config.addResource("hdfs-site.xml");
        config.addResource("core-site.xml");
        config.addResource("hbase-site.xml");


        Job newAPIJobConfiguration = Job.getInstance(config);
        newAPIJobConfiguration.getConfiguration().set(TableOutputFormat.OUTPUT_TABLE, hbaseTable);

        newAPIJobConfiguration.setOutputFormatClass(org.apache.hadoop.hbase.mapreduce.TableOutputFormat.class);

        JavaPairRDD<ImmutableBytesWritable, Put> hbasePuts = rawRdd.mapToPair(
                new PairFunction<Row, ImmutableBytesWritable, Put>() {

                    public Tuple2<ImmutableBytesWritable, Put> call(Row row) throws Exception {

                        Put put = new Put(Bytes.toBytes(UUID.randomUUID().toString()));

                        put.addColumn(Bytes.toBytes("info"),Bytes.toBytes("Path"),Bytes.toBytes(row.getString(0)));
                        put.addColumn(Bytes.toBytes("info"),Bytes.toBytes("Replication"),Bytes.toBytes(row.getInt(1)));
                        put.addColumn(Bytes.toBytes("info"),Bytes.toBytes("ModificationTime"),Bytes.toBytes(row.getString(2)));
                        put.addColumn(Bytes.toBytes("info"),Bytes.toBytes("AccessTime"),Bytes.toBytes(row.getString(3)));
                        put.addColumn(Bytes.toBytes("info"),Bytes.toBytes("PreferredBlockSize"),Bytes.toBytes(row.getInt(4)));
                        put.addColumn(Bytes.toBytes("info"),Bytes.toBytes("BlocksCount"),Bytes.toBytes(row.getInt(5)));
                        put.addColumn(Bytes.toBytes("info"),Bytes.toBytes("FileSize"),Bytes.toBytes(row.getInt(6)));
                        put.addColumn(Bytes.toBytes("info"),Bytes.toBytes("NSQUOTA"),Bytes.toBytes(row.getInt(7)));
                        put.addColumn(Bytes.toBytes("info"),Bytes.toBytes("DSQUOTA"),Bytes.toBytes(row.getInt(8)));
                        put.addColumn(Bytes.toBytes("info"),Bytes.toBytes("Permission"),Bytes.toBytes(row.getString(9)));
                        put.addColumn(Bytes.toBytes("info"),Bytes.toBytes("UserName"),Bytes.toBytes(row.getString(10)));
                        put.addColumn(Bytes.toBytes("info"),Bytes.toBytes("GroupName"),Bytes.toBytes(row.getString(11)));
                        return new Tuple2<ImmutableBytesWritable, Put>(new ImmutableBytesWritable(), put);
                    }
                });

        hbasePuts.saveAsNewAPIHadoopDataset(newAPIJobConfiguration.getConfiguration());
    }


}
