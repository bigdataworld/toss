package com.test.bd;

import org.apache.commons.io.IOUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.security.UserGroupInformation;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructType;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Properties;

import static org.apache.spark.sql.types.DataTypes.*;

/**
 * Utility Class for Common Functions for Stream Application
 */
public class AppUtils {

    /**
     * Method to Read File Data From HDFS
     * @param propFile
     * @return
     * @throws Exception
     */
    public static void streamHdfsData(String propFile) throws Exception{

        Properties appProp = getProperties(propFile);
        String nameNodeUrl = appProp.get("nameNodeUrl").toString();
        String inputPath = appProp.get("inputPath").toString();

        Configuration conf = new Configuration();
        conf.addResource("hdfs-site.xml");
        conf.addResource("core-site.xml");
        conf.set("fs.default.name",nameNodeUrl);

        //Enable KERBEROS
        UserGroupInformation.setConfiguration(conf);
       UserGroupInformation ugi = UserGroupInformation.getCurrentUser();
       ugi.setAuthenticationMethod(UserGroupInformation.AuthenticationMethod.KERBEROS);

        FileSystem fs = FileSystem.get(conf);
        Path hdfsDataPath = new Path(inputPath);
        BufferedReader fileReader = new BufferedReader(new InputStreamReader(fs.open(hdfsDataPath)));

        String dataLine =  fileReader.readLine();

        while (dataLine != null) {

            sendFileData(dataLine,propFile);
            System.out.println(dataLine);
            Thread.sleep(1000);
            dataLine = fileReader.readLine();

        }

        fileReader.close();
        fs.close();
    }


    /**
     *
     * @param dataLine
     * @throws Exception
     */

    public static void sendFileData(String dataLine,String propFile) throws Exception{



        Properties appProp = getProperties(propFile);
        String kafkaTopic = appProp.get("kafkaTopic").toString();
        String bootServers = appProp.get("kafkaBroker").toString();

        KafkaProducer kafkaProducer;
        Properties prop = new Properties();
        prop.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,bootServers);
        prop.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SASL_PLAINTEXT");
        prop.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,"org.apache.kafka.common.serialization.StringSerializer");
        prop.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,"org.apache.kafka.common.serialization.StringSerializer");
        kafkaProducer= new KafkaProducer<String,String>(prop);
        ProducerRecord record = new ProducerRecord(kafkaTopic,dataLine);
        kafkaProducer.send(record);
    }


    /**
     * Function to Load Properties
     */
    public static Properties getProperties(String fileName) throws Exception{

        Properties properties = new Properties();
        FileInputStream fis = new FileInputStream(fileName);
        properties.load(fis);
        fis.close();
        return properties;
    }

}
