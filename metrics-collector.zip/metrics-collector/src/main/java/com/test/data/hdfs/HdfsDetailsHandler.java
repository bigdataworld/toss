package com.test.data.hdfs;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.security.UserGroupInformation;

import java.io.IOException;


/**
 *
 */
public class HdfsDetailsHandler {

    public static void main(String args[]) throws IOException {

        System.out.println("--------------------------------------");
        System.out.println("HDFS Content Information");
        System.out.println("--------------------------------------");

        Configuration conf = new Configuration();
        conf.addResource("hdfs-site.xml");
        conf.addResource("core-site.xml");
        conf.set("fs.defaultFS",args[0]);
        Path inputPath = new Path(args[1]);

        UserGroupInformation.setConfiguration(conf);
        UserGroupInformation ugi = UserGroupInformation.getCurrentUser();
        ugi.setAuthenticationMethod(UserGroupInformation.AuthenticationMethod.KERBEROS);

        FileSystem fs = FileSystem.get(conf);
        System.out.println("Details  of  HDFS Path : "+inputPath);
        System.out.println("--------------------------------------");
        FileStatus[] parentStatus = fs.listStatus(inputPath);
        System.out.println("\tNumber of Contents :"+parentStatus.length);
        System.out.println("\tNumber of Sub Dir :"+HDFSUtils.getDirList(parentStatus).size() +" "+HDFSUtils.getDirList(parentStatus));
        System.out.println("\tNumber of Files :"+HDFSUtils.getFileList(fs,inputPath).size() +" "+HDFSUtils.getFileList(fs,inputPath));
        HDFSUtils.getContent(fs,parentStatus,"");
        System.out.println("--------------------------------------");

    }
}
