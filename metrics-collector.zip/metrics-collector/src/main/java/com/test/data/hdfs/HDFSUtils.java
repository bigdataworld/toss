package com.test.data.hdfs;

import org.apache.hadoop.fs.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class HDFSUtils {



    /**
     *
     * @param fs
     * @param status
     * @return
     * @throws IOException
     */
    public static void getContent(FileSystem fs,FileStatus[] status,String format) throws IOException {

        int levelIndex=1;

        for (int i = 0; i < status.length; i++) {
            FileStatus fileStatus = status[i];


            if (fileStatus.isDirectory()) {

                System.out.println("-------------------------------");
                System.out.println("Directory Name: "+fileStatus.getPath().getName());
                System.out.println("\tParent Name: "+fileStatus.getPath().getParent().getName());
                FileStatus[] subStatus = fs.listStatus(fileStatus.getPath());
                System.out.println("\tNumber of Content :"+subStatus.length);

                List<String> dirList = HDFSUtils.getDirList(subStatus);
                List<String>fileList = HDFSUtils.getFileList(fs,fileStatus.getPath());
                System.out.println("\tNumber of Sub Dir :"+dirList.size());

                ContentSummary hdfsDetails = fs.getContentSummary(fileStatus.getPath());
                if(dirList.size()!=0) {
                    System.out.println("\tSize of Sub Dir :"+hdfsDetails.getLength() +" B");
                    System.out.println("\tNames of Sub Dir :" + HDFSUtils.getDirList(subStatus));
                }
                System.out.println("\tNumber of Files :"+fileList.size());
                if(fileList.size()!=0) {
                    System.out.println("\tName of Files :" + HDFSUtils.getFileList(fs, fileStatus.getPath()));
                }
                    getContent(fs, subStatus, "\t");

                levelIndex++;
            }
        }
    }


    /**
     *
     * @param fs
     * @param inputPath
     * @return
     * @throws IOException
     */
    public static List<String> getFileList(FileSystem fs,Path inputPath)throws IOException{

        List<String> fileList = new ArrayList<String>();

        RemoteIterator<LocatedFileStatus> fileStatusIterator = fs.listFiles(inputPath,false);

        while (fileStatusIterator.hasNext()) {
            LocatedFileStatus fileStatus = fileStatusIterator.next();
            fileList.add(fileStatus.getPath().getName());

        }
        return fileList;
    }

    /**
     *
     * @param contentList
     * @return
     */
    public static List<String> getDirList(FileStatus[] contentList) {

        List<String> dirList = new ArrayList<String>();
        for (int i = 0; i < contentList.length; i++) {
            FileStatus fileStatus = contentList[i];

            if (fileStatus.isDirectory()) {
                dirList.add(fileStatus.getPath().getName());
            }
        }
        return dirList;
    }


    /**
     *
     * @param fs
     * @param inputPath
     * @return
     */
    public static ContentSummary getDirDetails(FileSystem fs ,Path inputPath) throws  IOException{

        ContentSummary hdfsDetails = fs.getContentSummary(inputPath);

        return hdfsDetails;

    }

}
