package com.test.bd;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.kafka010.ConsumerStrategies;
import org.apache.spark.streaming.kafka010.KafkaUtils;
import org.apache.spark.streaming.kafka010.LocationStrategies;
import sun.misc.JavaObjectInputStreamAccess;

import java.util.*;

public class KafkaSparkStream {

    public static void main(String args[]) throws  Exception {

        Properties appProp = AppUtils.getProperties(args[0]);
        String zooKeeperServer = appProp.get("zooKeeperServer").toString();
        String kafkaBroker = appProp.get("kafkaBroker").toString();
        String kafkaTopic = appProp.get("kafkaTopic").toString();
        String sparkMode = appProp.get("sparkMode").toString();
        String hbaseTable = appProp.get("hbaseTable").toString();

        SparkSession sparkSession = SparkSession
                .builder()
                .appName("Kafka HBase Integration")
                .master(sparkMode)
                .getOrCreate();


       Set<String> topics = Collections.singleton(kafkaTopic);

        Map<String,Object> kafkaparams =  new HashMap<>();

        kafkaparams.put("bootstrap.servers",kafkaBroker);
        kafkaparams.put("key.deserilizer", StringDeserializer.class);
        kafkaparams.put("value.deserilizer",StringDeserializer.class);
        kafkaparams.put("group.id","tempid");
        kafkaparams.put("auto.offset.reset","earliest");
        kafkaparams.put("enable.auto.commit","false");

        JavaStreamingContext javaDstream = new JavaStreamingContext
                (new JavaSparkContext(sparkSession.sparkContext()), Durations.seconds(20));

        JavaInputDStream<ConsumerRecord<String,String>> messages = KafkaUtils.createDirectStream(javaDstream,
                LocationStrategies.PreferConsistent(),
                ConsumerStrategies.Subscribe(topics,kafkaparams));

        JavaDStream<String> dataLines = messages.map(ConsumerRecord::value);

        dataLines.foreachRDD(new VoidFunction<JavaRDD<String>>() {

            @Override
            public void call(JavaRDD<String> rdd){

                JavaRDD<Row> rowRDD = rdd.map(new Function<String,Row>(){

                    public Row call(String msg){
                        Row row = RowFactory.create(msg);
                        return row;
                    }
                });

                StructType schema = DataTypes.createStructType(new StructField[]{
                        DataTypes.createStructField("messages",DataTypes.StringType,true)});

                Dataset<Row> streamDF = sparkSession.createDataFrame(rowRDD,schema);
            }

        });

        javaDstream.start();
        javaDstream.awaitTermination();

    }
}
